# Focus Logic

A Pen created on CodePen.

Original URL: [https://codepen.io/thabang-mogotsi/pen/WbQZqOE](https://codepen.io/thabang-mogotsi/pen/WbQZqOE).

